﻿using SubsonicWS.Common;
using SubsonicWS.Common.NestedElements;
using SubsonicWS.Exceptions;
using System.Xml.Serialization;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
$if$ ($targetframeworkversion$ >= 4.5)using System.Threading.Tasks;
$endif$
namespace $rootnamespace$
{
	[XmlRoot(Constants.SubResponse, Namespace = Constants.SubNamespace)]
    class $safeitemrootname$ : Response<$safeitemrootname$>
    {
		public async Task Request()
		{
			$safeitemrootname$ item = await Get();
			if (item.StatusValue == ResponseStatus.Failed)
                throw new ResponseStatusFailedException("" + $safeitemrootname$ +" failed", item.Error);
            this.Copy(item);
		}
    }
}
